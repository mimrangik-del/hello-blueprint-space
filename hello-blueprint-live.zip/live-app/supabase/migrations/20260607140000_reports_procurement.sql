-- ─── reports table ───────────────────────────────────────────────────────────
CREATE TABLE public.reports (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type           TEXT NOT NULL CHECK (type IN ('PM','CM')),
  equipment_tag  TEXT NOT NULL,
  date           DATE NOT NULL DEFAULT CURRENT_DATE,
  inspector      TEXT NOT NULL,
  findings       TEXT NOT NULL,
  linked_spares  INTEGER NOT NULL DEFAULT 0,
  severity       TEXT NOT NULL CHECK (severity IN ('High','Medium','Low')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TRIGGER trg_reports_updated_at
  BEFORE UPDATE ON public.reports
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "reports_select" ON public.reports
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "reports_insert" ON public.reports
  FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'manager') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "reports_update" ON public.reports
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'manager') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "reports_delete" ON public.reports
  FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'));

GRANT SELECT, INSERT, UPDATE, DELETE ON public.reports TO authenticated;
GRANT ALL ON public.reports TO service_role;

-- ─── procurement table ────────────────────────────────────────────────────────
CREATE TABLE public.procurement (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  spare_code      TEXT NOT NULL,
  spare_name      TEXT NOT NULL,
  quantity        INTEGER NOT NULL DEFAULT 1,
  priority_score  INTEGER NOT NULL DEFAULT 5 CHECK (priority_score BETWEEN 1 AND 10),
  estimated_cost  NUMERIC(12,2) NOT NULL DEFAULT 0,
  requested_by    TEXT NOT NULL,
  request_date    DATE NOT NULL DEFAULT CURRENT_DATE,
  status          TEXT NOT NULL DEFAULT 'Pending'
                    CHECK (status IN ('Pending','Approved','Rejected','Ordered')),
  justification   TEXT NOT NULL DEFAULT '',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TRIGGER trg_procurement_updated_at
  BEFORE UPDATE ON public.procurement
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

ALTER TABLE public.procurement ENABLE ROW LEVEL SECURITY;

CREATE POLICY "procurement_select" ON public.procurement
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "procurement_insert" ON public.procurement
  FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'manager') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "procurement_update" ON public.procurement
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'manager') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "procurement_delete" ON public.procurement
  FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'));

GRANT SELECT, INSERT, UPDATE, DELETE ON public.procurement TO authenticated;
GRANT ALL ON public.procurement TO service_role;
