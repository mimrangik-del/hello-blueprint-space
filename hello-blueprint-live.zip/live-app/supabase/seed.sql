-- ─── Seed: equipment ──────────────────────────────────────────────────────────
INSERT INTO public.equipment (tag, name, location, plant, criticality, status, manufacturer, model) VALUES
  ('RM-01', 'Raw Mill 1',       'Raw Grinding',          'Plant A — Karachi',    'Critical',    'Running',     'Loesche',  'LM 35.2+2'),
  ('K-01',  'Kiln 1',           'Pyro',                  'Plant A — Karachi',    'Critical',    'Running',     'FLSmidth', 'ROTAX-2'),
  ('K-02',  'Kiln 2',           'Pyro',                  'Plant C — Nooriabad',  'Critical',    'Maintenance', 'FLSmidth', 'ROTAX-2'),
  ('CM-01', 'Cement Mill 1',    'Finish Grinding',       'Plant B — Hub',        'Critical',    'Running',     'FL',       'UMS 4.6x14'),
  ('CM-02', 'Cement Mill 2',    'Finish Grinding',       'Plant B — Hub',        'Critical',    'Stopped',     'FL',       'UMS 4.6x14'),
  ('CR-01', 'Primary Crusher',  'Crushing',              'Plant A — Karachi',    'Important',   'Running',     'Hazemag',  'APPH 1313'),
  ('CV-08', 'Conveyor 08',      'Transport',             'Plant A — Karachi',    'Non-Critical','Running',     'Rexnord',  NULL),
  ('BH-03', 'Baghouse 3',       'Air Pollution Control', 'Plant C — Nooriabad',  'Important',   'Running',     'Intensiv', NULL)
ON CONFLICT (tag) DO NOTHING;

-- ─── Seed: spares (equipment_id looked up by tag) ─────────────────────────────
INSERT INTO public.spares (part_number, description, equipment_id, quantity_on_hand, min_quantity, unit_cost, criticality, status) VALUES
  ('SP-10421', 'Roller Bearing 22340',     (SELECT id FROM equipment WHERE tag='RM-01'), 0,   2,   8450,  'Critical',    'Out'),
  ('SP-10422', 'Kiln Tyre Pad',            (SELECT id FROM equipment WHERE tag='K-01'),  1,   4,   14200, 'Critical',    'Low'),
  ('SP-10588', 'V-Belt SPC 4500',          (SELECT id FROM equipment WHERE tag='CM-02'), 12,  6,   240,   'Important',   'OK'),
  ('SP-11003', 'Hydraulic Cylinder 80mm',  (SELECT id FROM equipment WHERE tag='CR-01'), 0,   1,   5200,  'Critical',    'Out'),
  ('SP-11220', 'Refractory Brick Magnesia',(SELECT id FROM equipment WHERE tag='K-02'),  320, 200, 35,    'Important',   'OK'),
  ('SP-11455', 'Gear Coupling GC-180',     (SELECT id FROM equipment WHERE tag='CM-01'), 2,   3,   1980,  'Important',   'Low'),
  ('SP-11620', 'Conveyor Belt CB-1200',    (SELECT id FROM equipment WHERE tag='CV-08'), 1,   1,   3600,  'Non-Critical','OK'),
  ('SP-11890', 'Bag Filter Cartridge',     (SELECT id FROM equipment WHERE tag='BH-03'), 8,   24,  95,    'Important',   'Low'),
  ('SP-12001', 'Limit Switch Heavy Duty',  NULL,                                         18,  10,  75,    'Non-Critical','OK'),
  ('SP-12110', 'Motor 250kW 6-Pole',       (SELECT id FROM equipment WHERE tag='CM-02'), 0,   1,   28400, 'Critical',    'Out')
ON CONFLICT (part_number) DO NOTHING;

-- ─── Seed: reports ────────────────────────────────────────────────────────────
INSERT INTO public.reports (type, equipment_tag, date, inspector, findings, linked_spares, severity) VALUES
  ('CM', 'CM-02', '2026-06-02', 'A. Khan',   'Excessive vibration on DE bearing of motor. Recommend immediate replacement.', 2, 'High'),
  ('PM', 'K-01',  '2026-05-28', 'R. Ahmed',  'Tyre pad wear at 70%. Plan replacement in next shutdown.',                     1, 'Medium'),
  ('PM', 'RM-01', '2026-05-22', 'S. Bhatti', 'Bearing temperature trending upward. Monitor weekly.',                         1, 'Medium'),
  ('CM', 'CR-01', '2026-05-18', 'A. Khan',   'Hydraulic cylinder leakage observed.',                                         1, 'High'),
  ('PM', 'BH-03', '2026-05-14', 'M. Imran',  'Cartridge differential pressure above 180 mbar.',                              1, 'Low');

-- ─── Seed: procurement ────────────────────────────────────────────────────────
INSERT INTO public.procurement (spare_code, spare_name, quantity, priority_score, estimated_cost, requested_by, request_date, status, justification) VALUES
  ('SP-10421', 'Roller Bearing 22340',    4,  9,  8450,  'M. Imran',  '2026-06-03', 'Pending',  'Out of stock — Raw Mill critical bearing.'),
  ('SP-10422', 'Kiln Tyre Pad',           6,  8,  14200, 'M. Imran',  '2026-06-01', 'Approved', 'Below min — long lead time imported item.'),
  ('SP-12110', 'Motor 250kW 6-Pole',      1,  10, 28400, 'M. Imran',  '2026-05-30', 'Ordered',  'Cement Mill 2 standby motor required.'),
  ('SP-11003', 'Hydraulic Cylinder 80mm', 2,  7,  5200,  'S. Bhatti', '2026-05-28', 'Pending',  'Replacement for leaking unit on crusher.'),
  ('SP-11890', 'Bag Filter Cartridge',    60, 6,  95,    'R. Ahmed',  '2026-05-25', 'Rejected', 'Stock arriving from prior order — defer.'),
  ('SP-11455', 'Gear Coupling GC-180',    2,  5,  1980,  'M. Imran',  '2026-05-22', 'Approved', 'Below minimum on CM-01.');
