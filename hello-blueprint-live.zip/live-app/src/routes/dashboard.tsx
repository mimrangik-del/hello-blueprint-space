import { createFileRoute, Link } from "@tanstack/react-router";
import {
  AlertTriangle, Package, ShoppingCart, ClipboardList, TrendingUp, ArrowRight,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { StatCard } from "@/components/StatCard";
import { StatusBadge, criticalityTone, stockTone, requestTone } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { useEquipment, useSpares, useProcurement, useReports } from "@/hooks/useData";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Equipment Assistant" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { data: sparesData, isLoading: sparesLoading } = useSpares();
  const { data: procurementData, isLoading: procLoading } = useProcurement();
  const { data: reportsData, isLoading: reportsLoading } = useReports();

  // Derive stats from live data
  const criticalShortages = sparesData?.filter(
    (s) => s.criticality === "Critical" && s.status !== "OK"
  ).length ?? 0;
  const belowMin = sparesData?.filter((s) => s.quantity_on_hand < s.min_quantity).length ?? 0;
  const pendingRequests = procurementData?.filter((p) => p.status === "Pending").length ?? 0;
  const openFindings = reportsData?.filter((r) => r.severity !== "Low").length ?? 0;

  const criticalSpares = sparesData
    ?.filter((s) => s.criticality === "Critical" && s.status !== "OK")
    .slice(0, 5) ?? [];

  const recentRequests = procurementData?.slice(0, 4) ?? [];
  const recentReports = reportsData?.slice(0, 4) ?? [];

  return (
    <AppShell
      title="Operations Dashboard"
      subtitle="All plants · Live data"
      actions={
        <>
          <Button variant="outline" size="sm">Import SAP Export</Button>
          <Button size="sm" asChild>
            <Link to="/procurement">
              Procurement list <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </>
      }
    >
      {/* ── KPI cards ── */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Critical Shortages" value={sparesLoading ? "—" : criticalShortages}
          hint="Below minimum stock" icon={AlertTriangle} tone="danger" />
        <StatCard label="Spares Below Min" value={sparesLoading ? "—" : belowMin}
          hint="All criticality levels" icon={Package} tone="warning" />
        <StatCard label="Pending Requests" value={procLoading ? "—" : pendingRequests}
          hint="Awaiting manager approval" icon={ShoppingCart} />
        <StatCard label="Open Findings" value={reportsLoading ? "—" : openFindings}
          hint="High & medium severity" icon={ClipboardList} tone="warning" />
      </div>

      {/* ── Critical spares + budget ── */}
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-lg border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <div>
              <h2 className="text-sm font-semibold">Critical spares below stock</h2>
              <p className="text-xs text-muted-foreground">Top items needing attention this cycle</p>
            </div>
            <Button variant="ghost" size="sm" asChild><Link to="/spares">View all</Link></Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Part</TableHead>
                <TableHead>Equipment</TableHead>
                <TableHead className="text-right">Stock</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sparesLoading
                ? Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      {Array.from({ length: 4 }).map((__, j) => (
                        <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                : criticalSpares.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell>
                        <div className="font-medium">{s.description}</div>
                        <div className="text-xs text-muted-foreground">{s.part_number}</div>
                      </TableCell>
                      <TableCell className="text-sm">
                        {(s.equipment as any)?.tag ?? "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {s.quantity_on_hand} / {s.min_quantity}
                      </TableCell>
                      <TableCell>
                        <StatusBadge label={s.status} tone={stockTone(s.status as any)} />
                      </TableCell>
                    </TableRow>
                  ))}
            </TableBody>
          </Table>
        </div>

        {/* ── Budget placeholder (no budget table yet — kept as static) ── */}
        <div className="rounded-lg border border-border bg-card p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Budget — FY 2026</h2>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </div>
          <p className="mt-3 text-3xl font-semibold tracking-tight tabular-nums">$290k</p>
          <p className="text-xs text-muted-foreground">Remaining of $1,200k</p>
          <div className="mt-4">
            <div className="mb-1.5 flex justify-between text-xs">
              <span className="text-muted-foreground">76% used</span>
              <span className="tabular-nums">$910k spent/committed</span>
            </div>
            <Progress value={76} />
          </div>
          <Button variant="outline" size="sm" className="mt-5 w-full" asChild>
            <Link to="/budget">Budget details</Link>
          </Button>
        </div>
      </div>

      {/* ── Recent procurement + reports ── */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <h2 className="text-sm font-semibold">Recent procurement requests</h2>
            <Button variant="ghost" size="sm" asChild><Link to="/procurement">All</Link></Button>
          </div>
          <ul className="divide-y divide-border">
            {procLoading
              ? Array.from({ length: 4 }).map((_, i) => (
                  <li key={i} className="px-5 py-3"><Skeleton className="h-8 w-full" /></li>
                ))
              : recentRequests.map((r) => (
                  <li key={r.id} className="flex items-center justify-between gap-3 px-5 py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{r.spare_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {r.spare_code} · Qty {r.quantity} · Priority {r.priority_score}
                      </p>
                    </div>
                    <StatusBadge label={r.status} tone={requestTone(r.status as any)} />
                  </li>
                ))}
          </ul>
        </div>

        <div className="rounded-lg border border-border bg-card shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <h2 className="text-sm font-semibold">Recent inspection reports</h2>
            <Button variant="ghost" size="sm" asChild><Link to="/reports">All</Link></Button>
          </div>
          <ul className="divide-y divide-border">
            {reportsLoading
              ? Array.from({ length: 4 }).map((_, i) => (
                  <li key={i} className="px-5 py-3"><Skeleton className="h-8 w-full" /></li>
                ))
              : recentReports.map((r) => (
                  <li key={r.id} className="px-5 py-3">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <StatusBadge label={r.type} tone={r.type === "CM" ? "destructive" : "info"} />
                        <span className="text-sm font-medium">{r.equipment_tag}</span>
                      </div>
                      <StatusBadge
                        label={r.severity}
                        tone={criticalityTone(
                          r.severity === "High" ? "Critical"
                            : r.severity === "Medium" ? "Important"
                            : "Non-Critical"
                        )}
                      />
                    </div>
                    <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{r.findings}</p>
                  </li>
                ))}
          </ul>
        </div>
      </div>
    </AppShell>
  );
}
