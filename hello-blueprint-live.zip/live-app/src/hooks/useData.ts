import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

// ─── Equipment ────────────────────────────────────────────────────────────────
export function useEquipment() {
  return useQuery({
    queryKey: ["equipment"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("equipment")
        .select("*")
        .order("tag");
      if (error) throw error;
      return data;
    },
  });
}

// ─── Spares ───────────────────────────────────────────────────────────────────
export function useSpares() {
  return useQuery({
    queryKey: ["spares"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("spares")
        .select("*, equipment(tag, name, plant)")
        .order("part_number");
      if (error) throw error;
      return data;
    },
  });
}

// ─── Reports ─────────────────────────────────────────────────────────────────
export function useReports() {
  return useQuery({
    queryKey: ["reports"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reports")
        .select("*")
        .order("date", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

// ─── Procurement ─────────────────────────────────────────────────────────────
export function useProcurement() {
  return useQuery({
    queryKey: ["procurement"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("procurement")
        .select("*")
        .order("priority_score", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
}

// ─── Update procurement status ───────────────────────────────────────────────
export function useUpdateProcurementStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from("procurement")
        .update({ status })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["procurement"] }),
  });
}
