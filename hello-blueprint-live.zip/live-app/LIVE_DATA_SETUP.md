# Going Live with Supabase Data

## What was changed

| File | Change |
|---|---|
| `src/hooks/useData.ts` | **NEW** — shared TanStack Query hooks for all 4 data sources |
| `src/routes/dashboard.tsx` | Rewritten — uses live spares, procurement, reports |
| `src/routes/spares.tsx` | Rewritten — joins equipment table for plant name |
| `src/routes/equipment.tsx` | Rewritten — queries equipment table |
| `src/routes/reports.tsx` | Rewritten — queries reports table |
| `src/routes/procurement.tsx` | Rewritten — queries procurement table, Approve/Reject buttons now write to DB |
| `supabase/migrations/20260607140000_reports_procurement.sql` | **NEW** — creates reports and procurement tables with RLS |
| `supabase/seed.sql` | **NEW** — seed data matching the original mock data |

---

## Step 1 — Push the new migration

```bash
supabase link --project-ref lfvtvifzptlefucpwuox
supabase db push
```

This creates the `reports` and `procurement` tables in your live Supabase project.

---

## Step 2 — Seed the database

Go to your Supabase dashboard:
1. Click **SQL Editor** in the left sidebar
2. Open the file `supabase/seed.sql` from this project
3. Paste its contents into the editor
4. Click **Run**

This inserts the 8 equipment records, 10 spares, 5 reports, and 6 procurement requests.

---

## Step 3 — Regenerate TypeScript types (optional but recommended)

After pushing the migration, regenerate the types so TypeScript knows about the new tables:

```bash
supabase gen types typescript --project-id lfvtvifzptlefucpwuox > src/integrations/supabase/types.ts
```

Then remove the manual type additions at the bottom of `types.ts`.

---

## Step 4 — Run the app

```bash
bun install
bun run dev
```

The `.env` file already has the correct `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`.

---

## How the Approve / Reject buttons work

On the Procurement page, clicking ✓ or ✗ on a Pending request now writes the new status
directly to Supabase and refreshes the list automatically via TanStack Query's
`invalidateQueries`. This requires the logged-in user to have the `manager` or `admin` role
(enforced by RLS). If you are testing without auth, temporarily disable RLS on the procurement
table in the Supabase dashboard.

---

## Notes

- The **Budget page** still uses static figures — there is no `budget` table in the schema yet.
  That page can stay as-is for now or a new migration can add a budget table.
- The plant filter on the Spares page is derived dynamically from live data, so it automatically
  reflects whatever plants are in your database.
